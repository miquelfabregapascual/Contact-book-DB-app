package com.example.bd.bd;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import com.example.bd.persones.Contactes;

import java.util.ArrayList;

public class DbContactes extends DbHelper{

    Context context;

    public DbContactes(@Nullable Context context) {
        super(context);
        this.context = context;
    }

    public long insertContacte(String nom, String cognoms, String telefon, String correu, String adreca) {
        long id = 0;
        try {
            DbHelper dbHelper = new DbHelper(context);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("nom", nom);
            values.put("cognoms", cognoms);
            values.put("telefon", telefon);
            values.put("mail", correu);
            values.put("adreca", adreca);

            id = db.insert(TABLE_CONTACTES, null, values);
        } catch (Exception ex) {
            ex.toString();
        }
        return id;
    }
    public ArrayList<Contactes> veureContactes(){
        DbHelper dbHelper = new DbHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ArrayList<Contactes> llistaContactes = new ArrayList<>();
        Contactes contacte = null;
        Cursor cursorContactes = null;

        cursorContactes = db.rawQuery("SELECT * FROM " + TABLE_CONTACTES, null);

        if(cursorContactes.moveToFirst()){
            do{
                contacte = new Contactes();
                contacte.setId(cursorContactes.getInt(0));
                contacte.setNom(cursorContactes.getString(1));
                contacte.setTelefon(cursorContactes.getString(2));
                contacte.setMail(cursorContactes.getString(3));
                llistaContactes.add(contacte);
            }while (cursorContactes.moveToNext());
        }
        cursorContactes.close();

        return llistaContactes;
    }

    public Contactes veureContacte(int id){

        DbHelper dbHelper = new DbHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        Contactes contacte = null;
        Cursor cursorContactes = null;

        cursorContactes = db.rawQuery(" SELECT * FROM " + TABLE_CONTACTES + " WHERE id = " + id + " LIMIT 1 ", null);

        if (cursorContactes.moveToFirst()){
            contacte = new Contactes();
            contacte.setId(cursorContactes.getInt(0));
            contacte.setNom(cursorContactes.getString(1));
            contacte.setTelefon(cursorContactes.getString(2));
            contacte.setMail(cursorContactes.getString(3));
            contacte.setAdreca(cursorContactes.getString(2));
            contacte.setCognoms(cursorContactes.getString(3));
        }
        cursorContactes.close();

        return contacte;
    }

    public boolean editarContacte(int id, String nom, String telefon, String mail){

        boolean correct = false;

        DbHelper dbHelper = new DbHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        try {
            db.execSQL( " UPDATE " + TABLE_CONTACTES + " SET Nom = '" + nom + "', telefon = '" + telefon + "', mail = '" + mail + "' WHERE id = '" + id + "'");
            correct = true;
        }catch (Exception ex){
            ex.toString();
        }finally {
            db.close();
        }

        return correct;
    }

    public boolean eliminarContacte(int id){

        boolean correct = false;

        DbHelper dbHelper = new DbHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        try {
            db.execSQL( " DELETE FROM " + TABLE_CONTACTES + " WHERE id = '" + id + "'");
            correct = true;
        }catch (Exception ex){
            ex.toString();
        }finally {
            db.close();
        }

        return correct;
    }

}
