package com.example.bd;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.bd.bd.DbContactes;
import com.example.bd.persones.Contactes;

public class VeureActivity extends AppCompatActivity {

    EditText txtNom, txtTelefon, txtMail;
    Button btnGuardar, btnEditar, btnEliminar;

    Contactes contacte;
    int id = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_veure);

        txtNom = findViewById(R.id.txtNom);
        txtTelefon = findViewById(R.id.txtTelefon);
        txtMail = findViewById(R.id.txtMail);
        btnGuardar = findViewById(R.id.btnGuardar);
        btnEditar = findViewById(R.id.btnEditar);
        btnEliminar = findViewById(R.id.btnEliminar);

        if(savedInstanceState == null){
            Bundle extras = getIntent().getExtras();
            if( extras == null){
                id = Integer.parseInt(null);
            }else {
                id = extras.getInt("ID");
            }
        }else {
            id = (int) savedInstanceState.getSerializable("ID");
        }

        DbContactes dbContactes = new DbContactes(VeureActivity.this);
        contacte = dbContactes.veureContacte(id);

        if( contacte != null ){
            txtNom.setText(contacte.getNom());
            txtTelefon.setText(contacte.getTelefon());
            txtMail.setText(contacte.getMail());
            btnGuardar.setVisibility(View.INVISIBLE);
            txtNom.setInputType(InputType.TYPE_NULL);
            txtTelefon.setInputType(InputType.TYPE_NULL);
            txtMail.setInputType(InputType.TYPE_NULL);

        }

        btnEditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(VeureActivity.this, EditarActivity.class);
                intent.putExtra("ID", id);
                startActivity(intent);
            }
        });

        btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(VeureActivity.this);
                builder.setMessage("Vols eliminar el contacte?").setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if(dbContactes.eliminarContacte(id)){
                            veureRegistre();
                        }
                    }
                }).setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                }).show();
            }
        });

    }
    private void veureRegistre() {
        Intent intent = new Intent( this, MainActivity.class);
        startActivity(intent);
    }
}