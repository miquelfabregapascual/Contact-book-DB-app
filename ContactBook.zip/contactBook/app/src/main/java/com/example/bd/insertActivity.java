package com.example.bd;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.bd.bd.DbContactes;

public class insertActivity extends AppCompatActivity {

    EditText txtNom, txtTelefon, txtMail, txtcognoms,txtadreca;
    Button btnGuardar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);

        txtNom = findViewById(R.id.txtNom);
        txtTelefon = findViewById(R.id.txtTelefon);
        txtMail = findViewById(R.id.txtMail);
        txtcognoms = findViewById(R.id.txtCognoms);
        txtadreca = findViewById(R.id.txtAdreca);
        btnGuardar = findViewById(R.id.btnGuardar);

        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nom = txtNom.getText().toString();
                String telefon = txtTelefon.getText().toString();
                String mail = txtMail.getText().toString();
                String cognoms = txtcognoms.getText().toString();
                String adreca = txtadreca.getText().toString();

                DbContactes dbContactes = new DbContactes(insertActivity.this);
                long id = dbContactes.insertContacte(nom, telefon, mail,cognoms, adreca);

                if(id > 0){
                    Toast.makeText(insertActivity.this, "CONTACTE GUARDAT", Toast.LENGTH_LONG).show();
                    net();
                } else {
                    Toast.makeText(insertActivity.this, "ERROR NO S'HA GUARDAT", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void net(){
        txtNom.setText("");
        txtTelefon.setText("");
        txtMail.setText("");
        txtadreca.setText("");
        txtcognoms.setText("");
    }
}
