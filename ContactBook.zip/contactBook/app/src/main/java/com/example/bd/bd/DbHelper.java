package com.example.bd.bd;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DbHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSIO = 2;
    private static final int DATABASE_VERSION = 2; // Incrementa el número de versió

    private static  final String DATABASE_NOM = "agenda.db";
    public static final String TABLE_CONTACTES = "t_contactes";

    public DbHelper(@Nullable Context context){
        super(context, DATABASE_NOM, null, DATABASE_VERSIO);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE " + TABLE_CONTACTES + "(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "nom TEXT NOT NULL," +
                "cognoms TEXT," +
                "telefon TEXT NOT NULL," +
                "mail TEXT NOT NULL," +
                "adreca TEXT)");
    }


    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        sqLiteDatabase.execSQL("DROP TABLE " + TABLE_CONTACTES);
        onCreate(sqLiteDatabase);

    }
}
