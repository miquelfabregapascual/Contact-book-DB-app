package com.example.bd.persones;

public class Contactes {

    private int id;
    private String nom;
    private String cognoms;
    private String telefon;
    private String mail;
    private String adreca;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }
    public String getAdreca() {
        return adreca;
    }
    public String getCognoms() {
        return cognoms;
    }

    public void setCognoms(String cognoms) {
        this.cognoms = cognoms;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }
    public void setAdreca(String adreca) {
        this.adreca = adreca;
    }

    public String getTelefon() {
        return telefon;
    }

    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }
}
