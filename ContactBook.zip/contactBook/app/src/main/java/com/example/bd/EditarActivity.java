package com.example.bd;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bd.bd.DbContactes;
import com.example.bd.persones.Contactes;

public class EditarActivity extends AppCompatActivity {

    EditText txtNom, txtTelefon, txtMail;
    Button btnGuardar;

    boolean correct = false;
    Contactes contacte;
    int id = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_veure);

        txtNom = findViewById(R.id.txtNom);
        txtTelefon = findViewById(R.id.txtTelefon);
        txtMail = findViewById(R.id.txtMail);
        btnGuardar = findViewById(R.id.btnGuardar);

        if(savedInstanceState == null){
            Bundle extras = getIntent().getExtras();
            if( extras == null){
                id = Integer.parseInt(null);
            }else {
                id = extras.getInt("ID");
            }
        }else {
            id = (int) savedInstanceState.getSerializable("ID");
        }

        DbContactes dbContactes = new DbContactes(EditarActivity.this);
        contacte = dbContactes.veureContacte(id);

        if( contacte != null ){
            txtNom.setText(contacte.getNom());
            txtTelefon.setText(contacte.getTelefon());
            txtMail.setText(contacte.getMail());
        }

        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!txtNom.getText().toString().equals("") && !txtTelefon.getText().toString().equals("")) {
                    correct = dbContactes.editarContacte(id, txtNom.getText().toString(), txtTelefon.getText().toString(), txtMail.getText().toString());

                    if (correct) {
                        Toast.makeText(EditarActivity.this, "CONTACTE MODIFICAT", Toast.LENGTH_LONG).show();
                        veureRegistre();
                    } else {
                        Toast.makeText(EditarActivity.this, "ERROR AL MODIFICAR EL CONTACTE", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(EditarActivity.this, "HAS D'EMPLENAR ELS CAMPS OBLIGATORIS ", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void veureRegistre() {
        Intent intent = new Intent( this, MainActivity.class);
        intent.putExtra("ID", id);
        startActivity(intent);
    }

}
