package com.example.bd.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bd.R;
import com.example.bd.VeureActivity;
import com.example.bd.persones.Contactes;

import java.util.ArrayList;

public class LlistaContactesAdapter extends RecyclerView.Adapter<LlistaContactesAdapter.ContacteViewHolder> {

    ArrayList<Contactes> llistaContactes;
    public LlistaContactesAdapter(ArrayList<Contactes> llistaContactes){
        this.llistaContactes = llistaContactes;
    }

    @NonNull
    @Override
    public ContacteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.llista_item_contacte, null, false);
        return new ContacteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ContacteViewHolder holder, int position) {
        holder.viewNom.setText(llistaContactes.get(position).getNom());
        holder.viewTelefon.setText(llistaContactes.get(position).getTelefon());
        holder.viewMail.setText(llistaContactes.get(position).getMail());
        holder.viewCognoms.setText(llistaContactes.get(position).getCognoms());
    }


    @Override
    public int getItemCount() {
        return llistaContactes.size();
    }

    public class ContacteViewHolder extends RecyclerView.ViewHolder {
        TextView viewNom, viewTelefon, viewMail, viewCognoms;

        public ContacteViewHolder(@NonNull View itemView) {
            super(itemView);

            viewNom = itemView.findViewById(R.id.viewNom);
            viewTelefon = itemView.findViewById(R.id.viewTelefon);
            viewMail = itemView.findViewById(R.id.viewMail);
            viewCognoms = itemView.findViewById(R.id.viewCognoms);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Context context = view.getContext();
                    Intent intent = new Intent(context, VeureActivity.class);
                    intent.putExtra("ID", llistaContactes.get(getAdapterPosition()).getId());
                    context.startActivity(intent);
                }
            });
        }
    }
}
